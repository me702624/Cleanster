
//   document.addEventListener("DOMContentLoaded", function() {
//     const sendButton = document.getElementById("sendButton");

//     sendButton.addEventListener("click", function(event) {
//       event.preventDefault(); // Prevent form submission

//       // Simulate a successful send action (replace this with actual sending logic)
//       showSuccessMessage();
//     });

//     function showSuccessMessage() {
//       const mailSection = document.querySelector(".mail_section");
//       const successMessage = document.createElement("p");
//       successMessage.textContent = "Message sent successfully!";
//       successMessage.classList.add("success-message");

//       // Clear form inputs
//       const inputs = mailSection.querySelectorAll(".email_text");
//       inputs.forEach(input => (input.value = ""));

//       // Clear textarea
//       const textarea = mailSection.querySelector(".massage_text");
//       textarea.value = "";

//       // Append success message and remove it after a few seconds
//       mailSection.appendChild(successMessage);
//       setTimeout(() => {
//         mailSection.removeChild(successMessage);
//       }, 3000);
//     }
//   });


 document.addEventListener("DOMContentLoaded", function() {
    const sendButton = document.getElementById("sendButton");
    const successMessage = document.querySelector(".success-message");

    sendButton.addEventListener("click", function(event) {
      event.preventDefault(); // Prevent form submission

      // Simulate a successful send action (replace this with actual sending logic)
      showSuccessMessage();
    });

    function showSuccessMessage() {
      successMessage.style.display = "block";

      // Clear form inputs after a delay
      setTimeout(() => {
        successMessage.style.display = "none";
        clearFormInputs();
      }, 2000);
    }

    function clearFormInputs() {
      const inputs = document.querySelectorAll(".email_text");
      const textarea = document.querySelector(".massage_text");

      inputs.forEach(input => (input.value = ""));
      textarea.value = "";
    }
  });



  // -------------------------
//  Popup
  function openPopup() {
    document.getElementById("popupOverlay").style.display = "block";
  }

  function closePopup() {
    document.getElementById("popupOverlay").style.display = "none";
  }

  document.addEventListener("DOMContentLoaded", function() {
    const becomeProviderLink = document.querySelector(".become-provider-link");
    const popupCloseButton = document.getElementById("popupCloseButton");

    if (becomeProviderLink) {
      becomeProviderLink.addEventListener("click", openPopup);
    }

    if (popupCloseButton) {
      popupCloseButton.addEventListener("click", closePopup);
    }
  });



const signinForm = document.getElementById('form-signin');
const signupForm = document.getElementById('form-signup');
const signinTab = document.getElementById('signin-tab');
const signupTab = document.getElementById('signup-tab');
const switchToSignin = document.getElementById('switch-to-signin');
const switchToSignup = document.getElementById('switch-to-signup');

signinTab.addEventListener('click', () => {
  signinForm.style.display = 'block';
  signupForm.style.display = 'none';
  signinTab.classList.add('active');
  signupTab.classList.remove('active');
});

signupTab.addEventListener('click', () => {
  signinForm.style.display = 'none';
  signupForm.style.display = 'block';
  signupTab.classList.add('active');
  signinTab.classList.remove('active');
});

switchToSignin.addEventListener('click', (event) => {
  event.preventDefault();
  signinForm.style.display = 'block';
  signupForm.style.display = 'none';
  signinTab.classList.add('active');
  signupTab.classList.remove('active');
});

switchToSignup.addEventListener('click', (event) => {
  event.preventDefault();
  signinForm.style.display = 'none';
  signupForm.style.display = 'block';
  signupTab.classList.add('active');
  signinTab.classList.remove('active');
});
